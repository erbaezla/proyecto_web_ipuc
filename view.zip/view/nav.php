<div class="navbar navbar-static-top" id="nav" role="navigation">
                
                <div class="container">
                    <div class="navbar-header">
                        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                            <span class="sr-only">Toggle navigation</span>
                            <i class="fa fa-align-justify"></i>
                        </button>
                        <a class="navbar-brand" href="#">
                            <img src="img/logo-blue.png" alt="">
                        </a>
                    </div>

                    <!-- Collect the nav links, forms, and other content for toggling -->
                    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                        <ul class="nav navbar-nav navbar-right">
                            <li class="active"><a href="#slider">Inicio</a>
                            </li>
                            <li><a href="#whoWeAre">Nosotros</a>
                            </li>
                            <li><a href="#pastor">Pastor</a>
                            </li>
                            <li><a href="#buyNow">Vivo</a>
                            </li>
                            <li><a href="#services">Servicios</a>
                            </li>
                            <li><a href="#eventos">Eventos</a>
                            </li>
                            <li><a href="#get-in-touch">Contacto</a>
                            </li>
                            <li class="social-nav visible-lg">
                                <li class="social-nav visible-lg">
                                <a href="https://www.facebook.com/paginaipucvillamaria/?fref=ts" target="_blank"><i class="fa fa-facebook"></i></a>
                                <a href="https://twitter.com/IPUCVillaMaria" target="_blank"><i class="fa fa-twitter"></i></a>
                                <a href="https://www.youtube.com/channel/UCHicWsR5Xsp-NI8DSSMiTjg" target="_blank"><i class="fa fa-youtube"></i></a>
                                <a href="https://www.instagram.com/ipucvm/" target="_blank"><i class="fa fa-camera"></i></a>                        
                                </li>

                        </ul>
                    </div>
                    <!-- /.navbar-collapse -->
                </div>
                <!--/.container -->
            </div>