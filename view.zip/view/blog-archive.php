<!doctype html>
<!--[if lt IE 7]><html lang="en" class="no-js ie6"><![endif]-->
<!--[if IE 7]><html lang="en" class="no-js ie7"><![endif]-->
<!--[if IE 8]><html lang="en" class="no-js ie8"><![endif]-->
<!--[if gt IE 8]><!-->
<html lang="en" class="no-js">
<!--<![endif]-->

<head>
    <meta charset="UTF-8">
    <title>Bondy - Multipurpose Bootstrap Landing Page Template - Blogs</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
    <link rel="shortcut icon" href="favicon.ico">

    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/font-awesome.min.css">
    <link rel="stylesheet" href="css/styles.css" title="mainStyle">

    <script src="js/modernizr.custom.32033.js"></script>

</head>

<body>
    <!-- Wrap all page content here -->
    <div id="wrap">

        <!-- Fixed navbar -->
        <div class="navbar navbar-fixed-top" id="nav" role="navigation">
            <div class="theme-switcher">
                <div class="colors">
                    <a href="javascript:void(0)" class="blue"></a>
                    <a href="javascript:void(0)" class="orange"></a>
                    <a href="javascript:void(0)" class="red"></a>
                </div>
                <a href="javascript:void(0)" class="Switcher"><span class="fa fa-pencil fa-lg"></span></a>
            </div>
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="#">
                        <img src="img/logo.png" alt="">
                    </a>
                </div>

                <!-- Collect the nav links, forms, and other content for toggling -->
                <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                    <ul class="nav navbar-nav navbar-right">
                        <li><a href="index.html">Home</a></li>
                        <li><a href="#">about</a></li>
                        <li><a href="#">services</a></li>
                        <li><a href="#">team</a></li>
                        <li><a href="#">our work</a></li>
                        <li><a href="#">contact</a></li>
                        <li><a href="blog-archive.html" class="active">blog</a></li>
                        <li class="social-nav">
                            <a href="#"><i class="fa fa-twitter"></i></a>
                            <a href="#"><i class="fa fa-facebook"></i></a>
                            <a href="#"><i class="fa fa-google-plus"></i></a>
                            <a href="#"><i class="fa fa-linkedin"></i></a>
                        </li>
                    </ul>
                </div>
                <!-- /.navbar-collapse -->
            </div>
            <!--/.container -->
        </div>
        <!--/.navbar -->

        <section class="well well-lg">
            <div class="container">
                <div class="row">
                    <div class="col-md-6">
                        <h2>blog</h2>
                    </div>
                    <div class="col-md-6">
                        <ol class="breadcrumb">
                            <li><a href="#">Home</a></li>
                            <li><a href="#">Library</a></li>
                            <li class="active">Data</li>
                        </ol>
                    </div>
                </div>
            </div>
        </section>

        <section id="blog">
            <div class="container">
                <div class="row">
                    <div class="col-md-9">
                        <div class="article">
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="col-sm-1 col-xs-2">
                                        <div class="row">
                                            <div class="type">
                                                <i class="fa fa-picture-o fa-2x"></i>
                                            </div>
                                            <div class="date">
                                                30<span>may</span>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-sm-11 col-xs-10">
                                        <div class="preview">
                                            <img src="http://lorempixel.com/g/800/350/nightlife" alt="" class="img-responsive">
                                        </div>
                                        <h3><a href="blog-single.html">Lorem ipsum dolor sit amet.</a></h3>
                                        <div class="article-details">
                                            <div class="author">
                                                <a href="#"><i class="fa fa-user"></i> Jon Doe</a>
                                            </div>
                                            <div class="tags">
                                                <i class="fa fa-tags"></i>
                                                <a href="#">Responsive</a>
                                            </div>
                                        </div>
                                        <p class="article-data">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Id illo excepturi, sint odio, adipisci saepe maiores minima in. Quo enim velit corporis illum sint accusamus esse nostrum eaque ullam, eligendi! Lorem ipsum dolor sit amet, consectetur adipisicing elit. Sed cum quasi nihil earum quam, laudantium maxime repellat architecto, consectetur laboriosam facilis aut accusamus officiis sequi dolore blanditiis eius, odio, ab.</p>
                                        <span class="divider"></span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="article">
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="col-sm-1 col-xs-2">
                                        <div class="row">
                                            <div class="type">
                                                <i class="fa fa-youtube-play fa-2x"></i>
                                            </div>
                                            <div class="date">
                                                30<span>may</span>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-sm-11 col-xs-10">
                                        <div class="preview flex-video widescreen">
                                            <iframe src="//www.youtube.com/embed/m5_AKjDdqaU" frameborder="0" allowfullscreen></iframe>
                                        </div>

                                        <h3><a href="blog-single.html">Lorem ipsum dolor sit amet.</a></h3>
                                        <div class="article-details">
                                            <div class="author">
                                                <a href="#"><i class="fa fa-user"></i> Jon Doe</a>
                                            </div>
                                            <div class="tags">
                                                <i class="fa fa-tags"></i>
                                                <a href="#">Responsive</a>
                                            </div>
                                        </div>
                                        <p class="article-data">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Id illo excepturi, sint odio, adipisci saepe maiores minima in. Quo enim velit corporis illum sint accusamus esse nostrum eaque ullam, eligendi! Lorem ipsum dolor sit amet, consectetur adipisicing elit. Sed cum quasi nihil earum quam, laudantium maxime repellat architecto, consectetur laboriosam facilis aut accusamus officiis sequi dolore blanditiis eius, odio, ab.</p>
                                        <span class="divider"></span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="article">
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="col-sm-1 col-xs-2">
                                        <div class="row">
                                            <div class="type">
                                                <i class="fa fa-youtube-play fa-2x"></i>
                                            </div>
                                            <div class="date">
                                                30<span>may</span>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-sm-11 col-xs-10">
                                        <div class="preview">
                                            <div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
                                                <!-- Indicators -->
                                                <ol class="carousel-indicators vertical">
                                                    <li data-target="#carousel-example-generic" data-slide-to="0" class="active"></li>
                                                    <li data-target="#carousel-example-generic" data-slide-to="1"></li>
                                                    <li data-target="#carousel-example-generic" data-slide-to="2"></li>
                                                </ol>

                                                <!-- Wrapper for slides -->
                                                <div class="carousel-inner">
                                                    <div class="item active">
                                                        <img src="http://lorempixel.com/800/350/nightlife/" alt="">
                                                    </div>
                                                    <div class="item">
                                                        <img src="http://lorempixel.com/800/350/" alt="">
                                                    </div>
                                                    <div class="item">
                                                        <img src="http://lorempixel.com/800/350/sports/" alt="">
                                                    </div>
                                                </div>

                                            </div>
                                        </div>

                                        <h3><a href="blog-single.html">Lorem ipsum dolor sit amet.</a></h3>
                                        <div class="article-details">
                                            <div class="author">
                                                <a href="#"><i class="fa fa-user"></i> Jon Doe</a>
                                            </div>
                                            <div class="tags">
                                                <i class="fa fa-tags"></i>
                                                <a href="#">Responsive</a>
                                            </div>
                                        </div>
                                        <p class="article-data">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Id illo excepturi, sint odio, adipisci saepe maiores minima in. Quo enim velit corporis illum sint accusamus esse nostrum eaque ullam, eligendi! Lorem ipsum dolor sit amet, consectetur adipisicing elit. Sed cum quasi nihil earum quam, laudantium maxime repellat architecto, consectetur laboriosam facilis aut accusamus officiis sequi dolore blanditiis eius, odio, ab.</p>
                                        <span class="divider"></span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="article">
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="col-sm-1 col-xs-2">
                                        <div class="row">
                                            <div class="type">
                                                <i class="fa fa-music fa-2x"></i>
                                            </div>
                                            <div class="date">
                                                30<span>may</span>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-sm-11 col-xs-10">
                                        <div class="preview">
                                            <iframe width="100%" height="450" scrolling="no" frameborder="no" src="https://w.soundcloud.com/player/?url=https%3A//api.soundcloud.com/users/1818488&amp;auto_play=false&amp;hide_related=false&amp;show_comments=true&amp;show_user=true&amp;show_reposts=false&amp;visual=true"></iframe>
                                        </div>

                                        <h3><a href="blog-single.html">Lorem ipsum dolor sit amet.</a></h3>
                                        <div class="article-details">
                                            <div class="author">
                                                <a href="#"><i class="fa fa-user"></i> Jon Doe</a>
                                            </div>
                                            <div class="tags">
                                                <i class="fa fa-tags"></i>
                                                <a href="#">Responsive</a>
                                            </div>
                                        </div>
                                        <p class="article-data">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Id illo excepturi, sint odio, adipisci saepe maiores minima in. Quo enim velit corporis illum sint accusamus esse nostrum eaque ullam, eligendi! Lorem ipsum dolor sit amet, consectetur adipisicing elit. Sed cum quasi nihil earum quam, laudantium maxime repellat architecto, consectetur laboriosam facilis aut accusamus officiis sequi dolore blanditiis eius, odio, ab.</p>
                                        <span class="divider"></span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="article">
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="col-sm-1 col-xs-2">
                                        <div class="row">
                                            <div class="type">
                                                <i class="fa fa-quote-right fa-2x"></i>
                                            </div>
                                            <div class="date">
                                                30<span>may</span>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-sm-11 col-xs-10">
                                        <div class="preview">
                                            <div class="quote">
                                                Lorem ipsum dolor sit amet, consectetur adipisicing elit. Porro nemo eos molestiae aperiam alias minima suscipit voluptate laboriosam dolorum quae fugit ab magnam in facilis aspernatur vitae possimus, a blanditiis!

                                                Modi reiciendis commodi nihil consectetur, culpa at iusto ipsum dolore cum natus doloremque nesciunt id reprehenderit aspernatur alias eius dolor obcaecati nam velit nulla? Ullam nulla repudiandae dolores adipisci ut.

                                                Enim repellat animi quam dolor, explicabo, modi quos. Doloremque ipsum sed magnam, corrupti unde reiciendis magni temporibus eaque! Inventore doloribus vero, hic laborum cum tempore porro illo ratione aliquid quisquam!

                                            </div>
                                        </div>
                                        <span class="divider"></span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="pagination-wrapper col-md-12 clearfix">
                            <ul class="pagination pagination-lg">
                                <li><a href="#">&laquo;</a></li>
                                <li class="active"><a href="#">1</a></li>
                                <li><a href="#">2</a></li>
                                <li><a href="#">3</a></li>
                                <li><a href="#">4</a></li>
                                <li><a href="#">5</a></li>
                                <li><a href="#">&raquo;</a></li>
                            </ul>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="side-block search">
                            <h4>Search Blog</h4>
                            <div class="form-group has-feedback">
                                <input type="text" class="form-control" placeholder="Search here...">
                                <button type="submit"><i class="fa fa-search form-control-feedback"></i></button>
                            </div>
                            <span class="divider"></span>
                        </div>
                        <div class="side-block">
                            <h4>Blog Categories</h4>
                            <ul>
                                <li><a href="#">Photoshop</a></li>
                                <li><a href="#">Web / Graphic Design</a></li>
                                <li><a href="#">Mobile Development</a></li>
                                <li><a href="#">Video Editing</a></li>
                                <li><a href="#">Logo Design & Branding</a></li>
                            </ul>
                            <span class="divider"></span>
                        </div>
                        <div class="side-block">
                            <h4>Latest Posts</h4>
                            <div class="media">
                                <a class="pull-left" href="#">
                                    <img class="media-object" src="http://lorempixel.com/60/60/" alt="...">
                                </a>
                                <div class="media-body">
                                    Lorem ipsum dolor sit amet, consectetur adipisicing elit.
                                    <a href="#">by Admin</a>
                                </div>
                            </div>
                            <div class="media">
                                <a class="pull-left" href="#">
                                    <img class="media-object" src="http://lorempixel.com/60/60/" alt="...">
                                </a>
                                <div class="media-body">
                                    Lorem ipsum dolor sit amet, consectetur adipisicing elit.
                                    <a href="#">by Admin</a>
                                </div>
                            </div>
                            <div class="media">
                                <a class="pull-left" href="#">
                                    <img class="media-object" src="http://lorempixel.com/60/60/" alt="...">
                                </a>
                                <div class="media-body">
                                    Lorem ipsum dolor sit amet, consectetur adipisicing elit.
                                    <a href="#">by Admin</a>
                                </div>
                            </div>
                            <span class="divider"></span>
                        </div>
                        <div class="side-block">
                            <h4>Text Widget</h4>
                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Repellendus fugit vitae non assumenda quo ipsam, doloremque aspernatur commodi, eligendi consequatur sunt officia, omnis.</p>
                            <span class="divider"></span>
                        </div>
                        <div class="side-block">
                            <h4>tags cloud</h4>
                            <a href="#" class="tag">design</a>
                            <a href="#" class="tag">development</a>
                            <a href="#" class="tag">photoshop</a>
                            <a href="#" class="tag">web design</a>
                            <a href="#" class="tag">logo</a>
                            <a href="#" class="tag">html5</a>
                            <span class="divider"></span>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section id="get-in-touch">
            <div class="container">
                <div class="row">
                    <div class="col-md-8 col-md-push-2 clearfix">
                        <div class="section-heading">
                            <h1>.get in touch</h1>
                            <h4>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Inventore reiciendis vel reprehenderit expedita cupiditate repellat debitis!</h4>
                            <span class="divider"></span>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-6">
                        <div class="contact-details">
                            <div class="detail">
                                <h4>Rune<span class="brandy">k</span> web agency.</h4>
                                <p>4 dsaaa St- Amman, Jordan</p>
                            </div>
                            <div class="detail">
                                <h4>call us</h4>
                                <p>+2 233 5438324</p>
                            </div>
                            <div class="detail">
                                <h4>email us</h4>
                                <p>Support@yourdomain.com</p>
                            </div>
                            <div class="detail">
                                <ul class="clearfix">
                                    <li><a href="#"><i class="fa fa-google-plus fa-2x"></i></a></li>
                                    <li><a href="#"><i class="fa fa-twitter fa-2x"></i></a></li>
                                    <li><a href="#"><i class="fa fa-facebook fa-2x"></i></a></li>
                                    <li><a href="#"><i class="fa fa-youtube fa-2x"></i></a></li>
                                    <li><a href="#"><i class="fa fa-pinterest fa-2x"></i></a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <form>
                            <div class="form-group has-feedback left">
                                <input type="text" class="form-control" placeholder="NAME">
                                <i class="fa fa-user form-control-feedback"></i>
                            </div>
                            <div class="form-group has-feedback left">
                                <input type="email" class="form-control" placeholder="Email">
                                <i class="fa fa-envelope-o form-control-feedback"></i>
                            </div>
                            <div class="form-group has-feedback left">
                                <textarea class="form-control" rows="7" placeholder="MESSAGE"></textarea>
                                <i class="fa fa-pencil-square-o form-control-feedback"></i>
                            </div>
                            <button class="btn btn-primary btn-lg pull-right" type="submit">SUBMIT</button>

                        </form>
                    </div>
                </div>
            </div>
        </section>

        <section id="map"></section>

        <footer id="site-footer">
            <div class="container">
                <div class="row">
                    <span class="divider grey"></span>
                    <h4>2014 ScoopTheme<span class="brandy">s</span> Agency.</h4>
                    <h5>by <a href="#">ScoopThemes</a></h5>
                    <a href="#" class="scroll-top"><img src="img/top.png" alt="" class="top"></a>
                </div>
            </div>
        </footer>
    </div>
    <!--/wrap-->

    <script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/stellar.js"></script>
    <script src="js/jquery.circliful.min.js"></script>
    <script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=AIzaSyASm3CwaK9qtcZEWYa-iQwHaGi3gcosAJc&sensor=false"></script>
    <script src="js/script.js"></script>
</body>

</html>