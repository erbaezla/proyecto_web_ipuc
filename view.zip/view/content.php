 <section id="whoWeAre">
            <div class="container">
                <div class="row">
                    <div class="col-md-8 col-md-push-2 clearfix">
                        <div class="section-heading scrollpoint sp-effect3">
                            <br>
                            <br>
                            <br>
                             <h1>.<span>V</span>ILLA MARÍA,CASA DE BENDICIÓN
                            </h1>
                            <h4>Somos una sede de la Iglesia Pentecostal Unida de Colombia (IPUC), ubicada en el barrio Villa María de la ciudad de Bogotá. La obra en este lugar inició en el año 1994 con el pastor Guillermo Rátiva, posteriormente fue administrada por el pastor José Valenzuela y desde el año 2010 es liderada por el pastor Edgar Quintero.</h4>
                            <span class="divider"></span>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="media scrollpoint sp-effect2">
                            <a class="pull-left" href="#">
                                <i class="media-object fa icon-stats-dots fa-4x"></i>
                            </a>
                            <div class="media-body">
                                <h4 class="media-heading">MISIÓN</h4>
                                <p>Cumplir el mandato de Jesucristo: “Id por todo el mundo y predicad el evangelio a toda criatura” (San Marcos 16:15)</p>
                            </div>  
                        </div>
                        <div class="media scrollpoint sp-effect2">
                            <a class="pull-left" href="#">
                                <i class="media-object fa fa-users fa-4x"></i>
                            </a>
                            <div class="media-body">
                                <h4 class="media-heading">CREEMOS</h4>
                                <p>En la doctrina de la Unicidad de Dios, con sus implicaciones cristológicas, y practica el bautismo en el nombre de Jesús. Por eso es considerada como parte de los pentecostales del nombre de Jesucristo o apostólicos.</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="media right scrollpoint sp-effect1">
                            <a class="pull-right" href="#">
                                <i class="media-object fa icon-ear fa-4x"></i>
                            </a>
                            <div class="media-body">
                                <h4 class="media-heading">VISIÓN</h4>
                                <p>Alcanzar a todos los que podamos, ganar a todos los que alcancemos, formar a todos los que ganemos, y utilizar a todos los que formemos.</p>
                            </div>
                        </div>
                        <div class="media right scrollpoint sp-effect1">
                            <a class="pull-right" href="#">
                                <i class="media-object fa fa-book fa-4x"></i>
                            </a>
                            <div class="media-body">
                                <h4 class="media-heading">LA BIBLIA</h4>
                                <p>Es la única autoridad dada por Dios al hombre, por tanto, toda doctrina, fe, esperanza e instrucción para la iglesia debe ser basada en ella. “Toda la Escritura es inspirada por Dios y útil para enseñar, para redargüir, para corregir, para instruir en justicia” (2 Timoteo 3:16).  </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="container">
                <div class="row">
                    <div class="col-md-8 col-md-push-2 clearfix">
                        <div class="section-heading scrollpoint sp-effect3">
                            <h1>.<span>U</span>N SOLO DIOS
                            </h1>
                            <h4>“Oye, Israel: Jehová nuestro Dios, Jehová uno es” (Deuteronomio 6:4). Creemos en el único Dios viviente, infinito en poder, santo, que posee deidad absoluta y es indivisible (Efesios 4:6). El Dios verdadero se ha manifestado como Padre en la creación, como Hijo en la redención, y como el Espíritu Santo por consolación (1 Corintios 8:6; 2 Corintios 5:19; Joel 2:28). Dios es Espíritu (Juan 4:24), incorpóreo, invisible, sin partes, y por tanto, sin ninguna limitación.</h4>
                            <span class="divider"></span>
                        </div>
                    </div>
                    <div class="col-md-12">
                        <div class="row">
                            <div class="col-md-12 scrollpoint sp-effect4">
                                <img src="img/samples/imac.png" class="img-responsive img-center" alt="">
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-3">
                                <div class="media vertical scrollpoint sp-effect5">
                                    <a href="#">
                                        <i class="media-object fa fa-university fa-2x"></i>
                                    </a>
                                    <div class="media-body">
                                        <h4 class="media-heading">JESÚS ES DIOS</h4>
                                        <br>
                                        <p>El único Dios verdadero, conocido como Jehová en el Antiguo Testamento, tomó forma de hombre, y como el Hijo del hombre, nació de la virgen María. En 1 Timoteo 3:16 Pablo dijo: 
                                        “E discutiblemente, grande es el misterio de la piedad: Dios fue manifestado en carne, justificado en el Espíritu, visto de los ángeles, predicado a los gentiles, creído en el mundo, recibido arriba en gloria”.
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="media vertical scrollpoint sp-effect5">
                                    <a href="#">
                                        <i class="media-object fa fa-fire fa-2x"></i>
                                    </a>
                                    <div class="media-body">
                                        <h4 class="media-heading">JESÚS ES EL NOMBRE DE DIOS</h4>
                                        <br>
                                        <p>Dios usó varios títulos en el Antiguo Testamento como: Elohim, Dios, El Dios Todopoderoso, El Shaddai, Jehová, y especialmente Jehová el Señor. Pero el profeta Isaías declaró la llegada del Mesías: "Porque un niño nos es nacido, hijo nos es dado, y el principado sobre su hombro; y se llamará su nombre Admirable, Consejero, Dios fuerte, Padre eterno, Príncipe de paz" (Isaías 9:6). La cual se cumplió en Mateo 1:21: "Y dará a luz un hijo, y Llamaras su nombre JESÚS, porque él salvara a su pueblo de sus pecados"</p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="media vertical scrollpoint sp-effect5">
                                    <a href="#">
                                        <i class="media-object fa fa-shield fa-2x"></i>
                                    </a>
                                    <div class="media-body">
                                        <h4 class="media-heading">SALVACIÓN</h4>
                                        <br>
                                        <p>La doctrina fundamental y básica de esta organización es el modelo bíblico de la salvación, la cual consiste en arrepentimiento, bautismo por inmersión en agua en el nombre del Señor Jesucristo para el perdón de pecados, y el bautismo del Espíritu Santo con la señal inicial de hablar en otras lenguas.</p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="media vertical scrollpoint sp-effect5">
                                    <a href="#">
                                        <i class="media-object fa fa-flag fa-2x"></i>
                                    </a>
                                    <div class="media-body">
                                        <h4 class="media-heading">ARREPENTIMIENTO Y CONVERSIÓN</h4>
                                         <p>La palabra arrepentimiento significa cambio de puntos de vista y de propósito, cambio de corazón, cambio de actitud y cambio de vida. Por lo tanto, el perdón de pecados se obtiene por el arrepentimiento genuino, reconociendo y abandonando los pecados. De esa forma somos justificados por fe en el Señor Jesucristo (Romanos 5:1).</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </section>

        <section id="highlights">
            <div class="container">
                <div class="row">
                    <div class="col-md-6">
                        <div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
                            <!-- Indicators -->
                            <ol class="carousel-indicators vertical">
                                <li data-target="#carousel-example-generic" data-slide-to="0" class="active"></li>
                                <li data-target="#carousel-example-generic" data-slide-to="1"></li>
                                <li data-target="#carousel-example-generic" data-slide-to="2"></li>
                            </ol>

                            <!-- Wrapper for slides -->
                            <div class="carousel-inner">
                                <div class="item active">
                                    <img src="./assets/img/samples/600-300/2.jpg" alt="">
                                </div>
                                <div class="item">
                                    <img src="./assets/img/samples/600-300/3.jpg" alt="">
                                </div>
                                <div class="item">
                                    <img src="./assets/img/samples/600-300/1.jpg" alt="">
                                </div>
                            </div>

                        </div>
                    </div>
                    <div class="col-md-6">
                        <h4>NUESTRO FUNDAMENTO</h4>
                        <p>Estamos fundamentados en las enseñanzas de los apóstoles y profetas, siendo la principal piedra del ángulo Jesucristo mismo. (Efesios 2.20; 1 Corintios 3:11).</p>
                        <ul>
                            <li>Bautizamos en el Nombre de Jesús</li>
                            <li>Recibimos el bautismo del Espíritu Santo</li>
                            <li>Creemos en la sanidad divina</li>
                            <li>Esperamos el levantamiento de la iglesia</li>
                        </ul>
                    </div>
                </div>
            </div>
        </section>

        <section id="features">
            <div class="container">
                <div class="row">
                    <div class="col-md-5 scrollpoint sp-effect1">
                        <img src="img/samples/ipad-bl.png" class="img-responsive ipad-image img-center" alt="">
                    </div>
                    <div class="col-md-7 scrollpoint sp-effect2">
                        <h1>.<span>I</span>PUC VILLA MARÍA
                        </h1>
                        <div class="media media-circle">
                            <a class="pull-left" href="#">
                                <i class="media-object fa fa-angle-right fa-2x"></i>
                            </a>
                            <div class="media-body">
                                <h4 class="media-heading">AMOR</h4>
                                <p>Somos una iglesia que ama a Dios sobre todas las cosas.</p>
                            </div>
                        </div>
                        <div class="media media-circle">
                            <a class="pull-left" href="#">
                                <i class="media-object fa fa-angle-right fa-2x"></i>
                            </a>
                            <div class="media-body">
                                <h4 class="media-heading">ESFUERZO</h4>
                                <p>Somos una iglesia que trabaja arduamente por predicar el evangelio de Jesucristo.</p>
                            </div>
                        </div>
                        <div class="media media-circle">
                            <a class="pull-left" href="#">
                                <i class="media-object fa fa-angle-right fa-2x"></i>
                            </a>
                            <div class="media-body">
                                <h4 class="media-heading">BENDICIÓN</h4>
                                <p>Somos una iglesia de bendición para la sociedad y todos los que nos visitan.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <section id="services">
            <div class="container">
                <div class="row">
                    <div class="col-md-8 col-md-push-2 clearfix">
                        <div class="section-heading scrollpoint sp-effect3">
                            <h1>.<span>S</span>ervicios</h1>
                            <h4>Realizamos diferentes cultos y actividades con diversos enfoques y propósitos.</h4>
                            <span class="divider"></span>
                        </div>
                    </div>
                    <div class="col-md-12">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="media media-services right scrollpoint sp-effect1">
                                    <a class="pull-right" href="#">
                                        <i class="media-object fa fa-mobile fa-2x"></i>
                                    </a>
                                    <div class="media-body">
                                        <h4 class="media-heading">DOMINGOS</h4>
                                        <p>Dos servicios dominicales 8:30 A.M. y 11:00 A.M.</p>
                                    </div>
                                </div>
                                <div class="media media-services right scrollpoint sp-effect2">
                                    <a class="pull-right" href="#">
                                        <i class="media-object fa fa-link fa-2x"></i>
                                    </a>
                                    <div class="media-body">
                                        <h4 class="media-heading">JUEVES</h4>
                                        <p>Culto dirigido por las damas 7:00 P.M.</p>
                                    </div>
                                </div>
                                <div class="media media-services right scrollpoint sp-effect1">
                                    <a class="pull-right" href="#">
                                        <i class="media-object fa fa-film fa-2x"></i>
                                    </a>
                                    <div class="media-body">
                                        <h4 class="media-heading">ESCUELA INFANTIL</h4>
                                        <p>Enseñanza especial para niños los días martes, jueves y domingos</p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="media media-services scrollpoint sp-effect2">
                                    <a class="pull-left" href="#">
                                        <i class="media-object fa fa-send-o fa-2x"></i>
                                    </a>
                                    <div class="media-body">
                                        <h4 class="media-heading">MARTES</h4>
                                        <p>Culto de oración 7:00 P.M.</p>
                                    </div>
                                </div>
                                <div class="media media-services scrollpoint sp-effect1">
                                    <a class="pull-left" href="#">
                                        <i class="media-object fa fa-shopping-cart fa-2x"></i>
                                    </a>
                                    <div class="media-body">
                                        <h4 class="media-heading">SÁBADOS</h4>
                                        <p>Culto dirigido por los jóvenes 7:00 P.M.</p>
                                    </div>
                                </div>
                                <div class="media media-services scrollpoint sp-effect2">
                                    <a class="pull-left" href="#">
                                        <i class="media-object fa fa-shopping-cart fa-2x"></i>
                                    </a>
                                    <div class="media-body">
                                        <h4 class="media-heading">NEW JESS</h4>
                                        <p>Enseñanza especial para adolescentes cada sábado</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <section id="testimonials">
            <div class="container">
                <div class="row">
                    <div class="col-md-8 col-md-push-2 clearfix">
                        <div class="section-heading scrollpoint sp-effect3">
                            <i class="fa fa-quote-left fa-4x"></i>
                            <h3>. ACOMPÁÑANOS</h3>
                            <h4>Ven y vive una experiencia real con Dios que cambiará tu vida para siempre.</h4>
                            <span class="divider"></span>
                        </div>
                    </div>
                    <div class="col-md-12">
                        <div id="testimonials-carousel" class="carousel slide scrollpoint sp-effect3" data-ride="carousel">
                            <!-- Wrapper for slides -->
                            <div class="carousel-inner">
                                <div class="item active">
                                    <p>Pedro les dijo: Arrepentíos, y bautícese cada uno de vosotros en el nombre de Jesucristo para perdón de los pecados; y recibiréis el don del Espíritu Santo.</p>
                                    <div class="row">
                                        <div class="col-md-4 col-md-push-5">
                                            <div class="author">
                                                <h5>HECHOS 2:38.</h5>
                                             </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="item">
                                    <p>Mas Dios muestra su amor para con nosotros, <br>
                                    en que siendo aún pecadores, Cristo murió por nosotros.</p>
                                    <div class="row">
                                        <div class="col-md-4 col-md-push-5">
                                            <div class="author">
                                                <h5>ROMANOS 5:8.</h5>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <!-- Controls -->
                            <a class="left carousel-control" href="#testimonials-carousel" data-slide="prev">
                                <i class="fa fa-angle-left fa-3x"></i>
                            </a>
                            <a class="right carousel-control" href="#testimonials-carousel" data-slide="next">
                                <i class="fa fa-angle-right fa-3x"></i>
                            </a>
                        </div>

                    </div>
                </div>
            </div>
        </section>
        <section id="buyNow">
            <div class="container">
                <br> 
                <div class="scrollpoint sp-effect1">
                    <h1 align="centre">.V<span>ivo</span></h1>
                </div> 
                <br> 
                <div class="row">
                    <div class="col-md-4">
                        <br>
                        <br>
                        <div class="fb-page" data-href="https://www.facebook.com/paginaipucvillamaria/" data-tabs="timeline" data-width="1800" data-height="500" data-small-header="true" data-adapt-container-width="true" data-hide-cover="true" data-show-facepile="true"><blockquote cite="https://www.facebook.com/paginaipucvillamaria/" class="fb-xfbml-parse-ignore"><a href="https://www.facebook.com/paginaipucvillamaria/">Ipuc Villa María</a></blockquote></div>
                    </div>
                    <div class="col-md-6">
                    </br>
                </br>
            </br>
            <iframe class="col-lg-12 col-md-12 col-sm-12 col-xs-12" width="900" height="315" src="https://www.youtube.com/embed/mraocMsqCH0" frameborder="0" allowfullscreen></iframe>
         </div>
            <div class="col-md-2" >
        </div>
    </div>
    </section> 
       <section id="pastor">
            <div class="container">
                <div class="row">
                    <div class="col-md-8 col-md-push-2 clearfix">
                        <div class="section-heading scrollpoint sp-effect3">
                            <br>
                            <br>
                            <h1>.<span>P</span>ASTOR IPUC VILLA MARÍA</h1>
                            <h4>Nuestro pastor, Edgar Quintero, ha servido en la Iglesia Pentecostal Unida de Colombia en compañía de su esposa, la hermana Sonia de Quintero, desde hace más 35 de años. Fue misionero por 16 años: primero en Venezuela y posteriormente en El Salvador. Actualmente es presbítero del Distrito 28. Fue posesionado en IPUC Villa María el 11 de febrero del año 2010 y desde ese momento Dios lo ha usado para rescatar a muchas personas y mejorar nuestro lugar de culto. Sirve al Señor en compañía de su familia y 27 equipos de trabajo.</h4>
                            <span class="divider"></span>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <section id="skills">
            <div class="container">
                <div class="row">
                    <div class="col-md-8 col-md-push-2 clearfix">
                        <div class="section-heading scrollpoint sp-effect3">
                        <img src="./assets/img/samples/team/3.png" alt="" class="img-responsive img-center">
                        <h3>.Pastor Edgar Quintero y Esposa</h3>
                        </div>
                    </div>
                </div>
             </div>
        </section>
            <section id="portfolio">
            <div class="container">
                <div class="row">
                    <div class="col-md-8 col-md-push-2 clearfix">
                        <div class="section-heading scrollpoint sp-effect3">
                            <h1>.<span>M</span>ISIONES</h1>
                            <span class="divider"></span>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <section>
            <div id="wrapper">

             <!-- Main-->
                    <div id="main">
                        <article class="thumb">
                            <a href="images/fulls/01.jpg" class="image"><img src="images/thumbs/01.jpg" alt="" /></a>
                        <h2 style="color:#fff;">MISIÓN MISIONES</h2>  
                        <p>#AVANZA#MISIÓN MISIONES 2018#VM AIRLINES</p>
                        </article>
                        <article class="thumb">
                            <a href="images/fulls/02.jpg" class="image"><img src="images/thumbs/02.jpg" alt="" /></a>
                            <h2 style="color:#fff;">MISIÓN MANTENIMIENTO</h2> 
                             <p>#AVANZA#MISIÓN MANTENIMIENTO</p>
                        </article>
                        <article class="thumb">
                            <a href="images/fulls/03.jpg" class="image"><img src="images/thumbs/03.jpg" alt="" /></a>
                           <h2 style="color:#fff;">MISIÓN ORDEN</h2> 
                            <p>#AVANZA#MISIÓN ORDEN</p>
                        </article>
                        <article class="thumb">
                            <a href="images/fulls/04.jpg" class="image"><img src="images/thumbs/04.jpg" alt="" /></a>
                            <h2 style="color:#fff;">MISIÓN INFANTÍL</h2> 
                             <p>#AVANZA#MISIÓN INFANTÍL</p>
                        </article>
                        <article class="thumb">
                            <a href="images/fulls/05.jpg" class="image"><img src="images/thumbs/05.jpg" alt="" /></a>
                            <h2 style="color:#fff;">MISIÓN NEW JESS</h2> 
                            <p>#AVANZA#MISIÓN NEW JESS#JESÚS EN LA META</p>
                        </article>
                        <article class="thumb">
                            <a href="images/fulls/06.jpg" class="image"><img src="images/thumbs/06.jpg" alt="" /></a>
                             <h2 style="color:#fff;">PRESENTACIÓN DE NIÑOS</h2> 
                             <p>#AVANZA#IPUCVM</p>
                        </article>
                    <!--<article class="thumb">
                            <a href="images/fulls/07.jpg" class="image"><img src="images/thumbs/07.jpg" alt="" /></a>
                            <h2>Mauris id tellus arcu</h2>
                            <p>Nunc blandit nisi ligula magna sodales lectus elementum non. Integer id venenatis velit.</p>
                        </article>
                        <article class="thumb">
                            <a href="images/fulls/08.jpg" class="image"><img src="images/thumbs/08.jpg" alt="" /></a>
                            <h2>Nunc vehicula id nulla</h2>
                            <p>Nunc blandit nisi ligula magna sodales lectus elementum non. Integer id venenatis velit.</p>
                        </article>
                        <article class="thumb">
                            <a href="images/fulls/09.jpg" class="image"><img src="images/thumbs/09.jpg" alt="" /></a>
                            <h2>Neque et faucibus viverra</h2>
                            <p>Nunc blandit nisi ligula magna sodales lectus elementum non. Integer id venenatis velit.</p>
                        </article>
                        <article class="thumb">
                            <a href="images/fulls/10.jpg" class="image"><img src="images/thumbs/10.jpg" alt="" /></a>
                            <h2>Mattis ante fermentum</h2>
                            <p>Nunc blandit nisi ligula magna sodales lectus elementum non. Integer id venenatis velit.</p>
                        </article>
                        <article class="thumb">
                            <a href="images/fulls/11.jpg" class="image"><img src="images/thumbs/11.jpg" alt="" /></a>
                            <h2>Sed ac elementum arcu</h2>
                            <p>Nunc blandit nisi ligula magna sodales lectus elementum non. Integer id venenatis velit.</p>
                        </article>
                        <article class="thumb">
                            <a href="images/fulls/12.jpg" class="image"><img src="images/thumbs/12.jpg" alt="" /></a>
                            <h2>Vehicula id nulla dignissim</h2>
                            <p>Nunc blandit nisi ligula magna sodales lectus elementum non. Integer id venenatis velit.</p>
                        </article>-->
                   </div>
            </section>
            <section id="eventos" >
                <div class="container">
                   <div class="row">
                    <div class="col-md-8 col-md-push-2 clearfix">
                        <div class="section-heading scrollpoint sp-effect3">
                        <br>
                        <br>
                            <h1>.<span>E</span>VENTOS</h1>

                            <span class="divider"></span>
                        </div>
                    </div>
                </div>
                <div class="row">

                    <iframe src="https://calendar.google.com/calendar/embed?height=600&amp;wkst=1&amp;bgcolor=%23ffffff&amp;src=comunica.svm%40gmail.com&amp;color=%232952A3&amp;src=%23contacts%40group.v.calendar.google.com&amp;color=%232952A3&amp;ctz=America%2FBogota" style="border-width:0" width="1200" height="600" frameborder="0" scrolling="no"></iframe>
                </br>
            </br>
        </br>
    </br>
    </br>   
</br>
</div>
</section>    
      <section id="twitter">
            <div class="container">
                <div class="row">
                    <div class="col-md-8 col-md-push-2 clearfix">
                        <div class="section-heading white scrollpoint sp-effect3">
                             <h1><span>#</span>AVANZA<span>#</span>IPUCVM
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div id="carousel-twitter" class="carousel slide" data-ride="carousel">
                        <!-- Indicators -->
                        <ol class="carousel-indicators">
                            <li data-target="#carousel-twitter" data-slide-to="0" class="active"></li>
                            <li data-target="#carousel-twitter" data-slide-to="1"></li>
                            <li data-target="#carousel-twitter" data-slide-to="2"></li>
                            <li data-target="#carousel-twitter" data-slide-to="3"></li>
                        </ol>

                        <!-- Wrapper for slides -->
                        <div class="carousel-inner">
                            <div class="item active">
                              <div class="row">
                                <div class="col-md-8 col-md-push-2">
                                        <a href="https://www.facebook.com/paginaipucvillamaria/?fref=ts" target="_blank" class="btn btn-empty text-center">
                                        <i class="fa fa-facebook"></i> Síguenos
                                    </a>
                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="row">
                                <div class="col-md-8 col-md-push-2">
                                    <a href="https://twitter.com/IPUCVillaMaria" target="_blank"  class="btn btn-empty text-center">
                                        <i class="fa fa-twitter"></i> Síguenos
                                    </a> 
                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="row">
                                <div class="col-md-8 col-md-push-2">
                                    <a href="https://www.youtube.com/channel/UCHicWsR5Xsp-NI8DSSMiTjg" target="_blank" class="btn btn-empty text-center">
                                        <i class="fa fa-youtube"></i> Síguenos
                                    </a> 
                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="row">
                                <div class="col-md-8 col-md-push-2">
                                    <a href="https://www.instagram.com/ipucvm/" target="_blank" class="btn btn-empty text-center">
                                        <i class="fa fa-camera"></i> Síguenos
                                    </a> 
                                </div>
                            </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
